//
//  DetailView.swift
//  GifSwiftUI
//
//  Created by Praveen Verma on 16/04/25.
//

import SwiftUI

struct DetailView: View {
    
    let product: Product
    
    
    
    var body: some View {
        
       
        
        VStack(spacing: 0) {
            // Custom header
            HStack {
                Text("Cart")
                    .font(.title2)
                    .bold()
                Spacer()
                HStack(spacing: 16) {
                    Image(systemName: "heart")
                    Image(systemName: "square.and.arrow.up")
                }
                .font(.title2)
            }
            .padding()

            TabView {
 
                
                AsyncImage(url: URL(string: product.image)) { image in
                    image
                        .resizable()
                        .scaledToFit()
                } placeholder: {
                    ProgressView()
                }
                .padding()
                
            }
            .frame(height: 240)
            .tabViewStyle(PageTabViewStyle())

            VStack(alignment: .leading, spacing: 12) {
                Text(product.title)
                    .font(.title3)
                    .bold()

                HStack {
                    Label("4.8", systemImage: "star.fill")
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)

                    Text("117 reviews")
                        .font(.caption)
                        .foregroundColor(.gray)

                    Label("94%", systemImage: "hand.thumbsup")
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)

                    Label("8", systemImage: "message")
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color(.systemGray6))
                        .cornerRadius(8)
                }

                HStack {
                    Text("£\(String(format: "%.2f", product.price))")
                        .font(.title2)
                        .bold()
                    Spacer()
                    Text("from £14 per month")
                        .font(.footnote)
                        .foregroundColor(.gray)
                }

                Text("The Nintendo Switch gaming console is a compact device that can be taken everywhere. This portable super device is also equipped with 2 gamepads.")
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .lineLimit(4)

                Button("Read more") {}
                    .font(.caption)
                    .foregroundColor(.blue)

                Spacer()

                VStack(spacing: 8) {
                    Button("Add to cart") {}
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.green)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                        .font(.headline)

                    Text("Delivery on 26 October")
                        .font(.footnote)
                        .foregroundColor(.gray)
                }
            }
            .padding()
        }
    }
    
    
    
}

#Preview {
    DetailView(product: Product(id: 1, title: "Sample Product", price: 19.99, image: "https://via.placeholder.com/150"))
}



struct ProductCard: View {
    let product: Product

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            ZStack(alignment: .topTrailing) {
                AsyncImage(url: URL(string: product.image)) { image in
                    image
                        .resizable()
                        .scaledToFit()
                        .frame(width: 160, height: 160)
                        .cornerRadius(16)
                } placeholder: {
                    RoundedRectangle(cornerRadius: 16)
                        .fill(Color(.systemGray5))
                        .frame(width: 160, height: 160)
                        .overlay(ProgressView())
                }

                Image(systemName: "heart")
                    .padding(8)
                    .foregroundColor(.gray)
            }
            
            Spacer()
            
            Text(product.title)
                .font(.subheadline)
                .lineLimit(2)
            Text("£\(String(format: "%.2f", product.price))")
                .bold()
            
            Spacer()
        }
        .frame(width: 160)
        .frame(maxHeight: .infinity )
        
//        .background(Color.red)
    }
}

struct CategoryItem: View {
    let image: String
    let name: String

    var body: some View {
        VStack(spacing: 8) {
            Image(systemName: image)
                .resizable()
                .scaledToFit()
                .frame(width: 32, height: 32)
                .padding()
                .background(Color(.systemGray6))
                .clipShape(Circle())
            Text(name)
                .font(.caption)
        }
    }
}
