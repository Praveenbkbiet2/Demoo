//
//  CartView.swift
//  GifSwiftUI
//
//  Created by Praveen Verma on 16/04/25.
//

import SwiftUI

struct CartView: View {
    @State private var selectedAll = true
    @State private var quantities = [0: 1, 1: 1]
    
    var cartItems: [CartItem] = [
        CartItem(id: 0, title: "Nintendo Switch Lite, Yellow", price: 109.00, imageName: "gamecontroller"),
        CartItem(id: 1, title: "The Legend of Zelda: Tears of the Kingdom (Nintendo Switch)", price: 39.00, imageName: "photo")
    ]
    
    var body: some View {
        VStack(spacing: 16) {
            
           
                
                // Header
                HStack {
                    Text("Cart")
                        .font(.title2).bold()
                    Spacer()
                    Circle()
                        .frame(width: 30, height: 30)
                        .foregroundColor(.gray.opacity(0.1))
                        .overlay(Image(systemName: "ellipsis").rotationEffect(.degrees(90)))
                }
                .padding(.horizontal)
                
          
                // Address
                HStack {
                    Image(systemName: "mappin.and.ellipse")
                        .foregroundColor(.gray)
                    Text("92 High Street, London")
                    Spacer()
                    Image(systemName: "chevron.right")
                        .foregroundColor(.gray)
                }
                .padding()
                .background(Color.gray.opacity(0.1))
                .cornerRadius(12)
                .padding(.horizontal)
                
                // Select All
                HStack {
                    Toggle(isOn: $selectedAll) {
                        Text("Select all")
                            .fontWeight(.semibold)
                    }
                    .toggleStyle(CheckboxToggleStyle())
                    Spacer()
                    Image(systemName: "square.and.arrow.up")
                    Image(systemName: "trash")
                }
                .padding(.horizontal)
                
            ScrollView {
                // Cart Items
                ForEach(cartItems) { item in
                    HStack(spacing: 12) {
                        Toggle("", isOn: .constant(true))
                            .toggleStyle(CheckboxToggleStyle())
                            .frame(width: 30)
                        
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.gray.opacity(0.2))
                            .frame(width: 60, height: 60)
                            .overlay(Image(systemName: item.imageName).resizable().scaledToFit().padding(10))
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text(item.title)
                                .font(.subheadline)
                                .lineLimit(2)
                            Text("£\(String(format: "%.2f", item.price))")
                                .font(.subheadline).bold()
                        }
                        Spacer()
                        
                        HStack(spacing: 8) {
                            Button(action: {
                                if let qty = quantities[item.id], qty > 1 {
                                    quantities[item.id] = qty - 1
                                }
                            }) {
                                Image(systemName: "minus.circle")
                            }
                            Text("\(quantities[item.id] ?? 1)")
                            Button(action: {
                                if let qty = quantities[item.id] {
                                    quantities[item.id] = qty + 1
                                }
                            }) {
                                Image(systemName: "plus.circle")
                            }
                        }
                        .font(.title3)
                    }
                    .padding(.horizontal)
                }
            }
            Spacer()
            
            // Checkout Button
            Button(action: {}) {
                Text("Checkout")
                    .frame(maxWidth: .infinity)
                    .padding()
                    
                    .background(Color(#colorLiteral(red: 0.839, green: 0.925, blue: 0.133, alpha: 1)))
                    .foregroundColor(.black)
                    .cornerRadius(12)
                    .padding(.horizontal)
                    .padding(.bottom,40)
            }
        }
        .padding(.top)
    }
}

// MARK: - Cart Item Model
struct CartItem: Identifiable {
    let id: Int
    let title: String
    let price: Double
    let imageName: String
}

// MARK: - Checkbox Toggle Style
struct CheckboxToggleStyle: ToggleStyle {
    func makeBody(configuration: Configuration) -> some View {
        Button(action: { configuration.isOn.toggle() }) {
            Image(systemName: configuration.isOn ? "checkmark.circle.fill" : "circle")
                .foregroundColor(configuration.isOn ? .green : .gray)
                .font(.title3)
        }
    }
}

#Preview {
    CartView()
}
