//
//  MainTabView.swift
//  GifSwiftUI
//
//  Created by Praveen Verma on 16/04/25.
//

import Foundation
import SwiftUI


struct MainTabView: View {
    
    let product: Product
    
    var body: some View {
        TabView {
            NavigationStack {
                HomeView()
            }
            .tabItem {
                Image(systemName: "house.fill")
                Text("Home")
            }

            Text("Catalog")
                .tabItem {
                    Image(systemName: "square.grid.2x2")
                    Text("Catalog")
                }

            
            CartView()
                .tabItem {
                    Image(systemName: "cart")
                    Text("Cart")
                }

            Text("Favorites")
                .tabItem {
                    Image(systemName: "heart")
                    Text("Favorites")
                }

            Text("Profile")
                .tabItem {
                    Image(systemName: "person")
                    Text("Profile")
                }
        }
    }
}
