//
//  DemoAssignmentApp.swift
//  DemoAssignment
//
//  Created by Praveen Verma on 16/04/25.
//

import SwiftUI

@main
struct DemoAssignmentApp: App {
    var body: some Scene {
        WindowGroup {
            MainTabView(product: Product(id: 0, title: "Placeholder", price: 0.0, image: "https://via.placeholder.com/150"))
        }
    }
}
