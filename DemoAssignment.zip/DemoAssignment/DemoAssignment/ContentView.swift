//
//  ContentView.swift
//  GifSwiftUI
//
//  Created by Praveen Verma on 10/04/25.


import SwiftUI

struct Product: Identifiable, Codable {
    let id: Int
    let title: String
    let price: Double
    let image: String
}

class ProductViewModel: ObservableObject {
    @Published var products: [Product] = []

    func fetchProducts() {
        guard let url = URL(string: "https://fakestoreapi.com/products") else { return }

        URLSession.shared.dataTask(with: url) { data, _, error in
            if let data = data {
                do {
                    let products = try JSONDecoder().decode([Product].self, from: data)
                    DispatchQueue.main.async {
                        self.products = products
                    }
                } catch {
                    print("Decoding error:", error)
                }
            }
        }.resume()
    }
}



struct HomeView: View {
    @StateObject private var viewModel = ProductViewModel()
    @State private var flashSaleTimer = 10763

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                // Top Bar
                HStack {
                    Image(systemName: "gearshape.fill")
                        .foregroundColor(.black)
                        .padding(8)
                        .background(Color.green.opacity(0.2))
                        .clipShape(Circle())

                    Spacer()

                    VStack(spacing: 2) {
                        Text("Delivery address")
                            .font(.caption)
                            .foregroundColor(.gray)
                        Text("92 High Street, London")
                            .font(.headline)
                    }

                    Spacer()

                    Image(systemName: "bell.badge")
                        .font(.title3)
                        .foregroundColor(.gray)
                }
                .padding(.horizontal)
                .padding(.top)

                // Search Bar
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.gray)
                    TextField("Search the entire shop", text: .constant(""))
                }
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
                .padding(.horizontal)

                // Promo Banner
                HStack {
                    Text("Delivery is ")
                    Text("50%")
                        .fontWeight(.bold)
                        .foregroundColor(.green)
                    Text(" cheaper")
                    Spacer()
                    Image(systemName: "leaf.fill")
                        .foregroundColor(.green)
                }
                .padding()
                .background(Color.green.opacity(0.1))
                .cornerRadius(12)
                .padding(.horizontal)

                // Categories
                VStack(alignment: .leading) {
                    HStack {
                        Text("Categories")
                            .font(.title3)
                            .bold()
                        Spacer()
                        Text("See all")
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal)

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 24) {
                            CategoryItem(image: "rectangle.grid.1x2", name: "Phones")
                            CategoryItem(image: "gamecontroller", name: "Consoles")
                            CategoryItem(image: "laptopcomputer", name: "Laptops")
                            CategoryItem(image: "camera", name: "Cameras")
                            CategoryItem(image: "headphones", name: "Audio")
                        }
                        .padding(.horizontal)
                    }
                }

                // Flash Sale
                VStack(alignment: .leading) {
                    HStack {
                        Text("Flash Sale")
                            .font(.title3)
                            .bold()
                        Spacer()
                        Text(timeString(time: flashSaleTimer))
                            .font(.caption)
                            .fontWeight(.bold)
                            .padding(6)
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(6)
                        Text("See all")
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal)

                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 16) {
                            ForEach(viewModel.products) { product in
                                NavigationLink(destination: DetailView(product: product)) {
                                    ProductCard(product: product)
                                }
                                .buttonStyle(PlainButtonStyle()) // To remove default styling
                            }
                        }
                        .padding(.horizontal)
                    }
                }
            }
            .padding(.bottom, 10)
        }
        .onAppear {
            viewModel.fetchProducts()
            Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
                if flashSaleTimer > 0 {
                    flashSaleTimer -= 1
                }
            }
        }
    }

    func timeString(time: Int) -> String {
        let hours = time / 3600
        let minutes = (time % 3600) / 60
        let seconds = time % 60
        return String(format: "%02d:%02d:%02d", hours, minutes, seconds)
    }
}

 


#Preview {
    MainTabView(product: Product(id: 1, title: "Sample Product", price: 19.99, image: "https://via.placeholder.com/150"))
}




 
//import SwiftUI
//
//struct ContentView: View {
//    var body: some View {
//        VStack {
//            GIFImage(gifName: "MyGf")
//            
//                .frame(maxWidth: .infinity)
//                .frame(maxHeight: .infinity)
//            
//             
//                
//                 
//        }
//        .padding()
//    }
//}
//#Preview {
//    ContentView()
//}
//
//struct GIFImage: UIViewRepresentable {
//    let gifName: String
//
//    func makeUIView(context: Context) -> UIView {
//        let containerView = UIView()
//
//        let imageView = UIImageView()
//        imageView.translatesAutoresizingMaskIntoConstraints = false
//        imageView.contentMode = .scaleAspectFill
//        imageView.clipsToBounds = true
//        imageView.image = UIImage.gifImageWithName(gifName)
//        imageView.backgroundColor = .red
//
//        containerView.addSubview(imageView)
//
//         
//        NSLayoutConstraint.activate([
//            imageView.leadingAnchor.constraint(equalTo: containerView.leadingAnchor),
//            imageView.trailingAnchor.constraint(equalTo: containerView.trailingAnchor),
//            imageView.topAnchor.constraint(equalTo: containerView.topAnchor),
//            imageView.bottomAnchor.constraint(equalTo: containerView.bottomAnchor)
//        ])
//
//        return containerView
//    }
//
//    func updateUIView(_ uiView: UIView, context: Context) {
//        // No dynamic updates needed
//    }
//}
